<?php
include_once ("");
$connect = define("host", "localhost");
$data = define ("database", "lawal");
$user = define ("username", "test");
$pass = define ("password", "");
$connection = mysqli_connect("$connect","");

?>
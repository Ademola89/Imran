 <?php
 
$connection= mysqli_connect("localhost","root","","hookme");
if (!$connection){
    die (("failed").mysqli_connect_error());
}
 
 ?>
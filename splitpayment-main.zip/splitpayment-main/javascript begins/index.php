<!doctype>
<html>
<head>

 <head>
<body>
<h2>Javascripts</h2>








<script>
console.log("jiji");
</script>
</body>
</html>
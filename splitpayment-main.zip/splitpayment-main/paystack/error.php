
<!doctype html>
<html>
<head>
<script src="https://js.paystack.co/v1/inline.js"></script>
</head>
<body>

<h2>failed</h2>
</body>
</html>